##JSONDevice
This module has been derived from the [XMLDevice](https://github.com/pz1/ZWayModules/tree/master/XMLDevice) module.

It is meant to turn a single JSON element into a virtual device.

In the configuration screen the user has to specify a number of parameters that defines the virtual device.

It is important to adhere as close as possible to standard terminology as defined in the opt/z-way-server/translations/scales.xml file on your RaspberryPi.
